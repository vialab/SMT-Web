package vialab.SMT;

/**
 * 	New code should use SMT instead of TouchClient, although it will
 *  be kept for backwards compatibility for an indefinite length of time
 *	@deprecated
 */
public class TouchClient extends SMT {
}
